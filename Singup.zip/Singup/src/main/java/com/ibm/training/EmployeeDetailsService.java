package com.ibm.training;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeDetailsService {

	@Autowired
	EmployeeDetailsDao dao;
	
	//Signup
	public void addUser(EmployeeDetails user) {
		dao.addUser(user);
		
	}

	//Login
	 List<EmployeeDetails> getUsers() {
		
		return (List<EmployeeDetails>) dao.getUsers();
	}



}
