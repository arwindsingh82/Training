package com.ibm.training;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDetailsDao {

	@Autowired
	EmployeeDetailsRepository repo;
	
	public void addUser(EmployeeDetails user) {
		repo.save(user);
		
	}

	public List<EmployeeDetails> getUsers() {
	
		return (List<EmployeeDetails>) repo.findAll();
	}

	
	

	
}
