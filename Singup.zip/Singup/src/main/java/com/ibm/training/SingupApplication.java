package com.ibm.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SingupApplication {

	public static void main(String[] args) {
		SpringApplication.run(SingupApplication.class, args);
		System.out.println("working");
	}

}
