package com.ibm.training;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class EmployeeDetailsController {

	//Have the service injected here
		@Autowired
		EmployeeDetailsService service;
		
	
		//Add new user from register page
		@RequestMapping(method = RequestMethod.POST, value = "/register")
		void addUser(@RequestBody EmployeeDetails user) {
			service.addUser(user);
		}
	
       //Login
		@RequestMapping("/login")
		List<EmployeeDetails> getUsers() {
			return service.getUsers();
		}
		
		
}
